# Eclipse SMP Website

A responsive, dark futuristic landing page for Eclipse SMP. Built with plain HTML, CSS, and JavaScript; no build tools required.

## Preview locally
1. Extract the ZIP file.
2. Open `index.html` in a modern browser.

## Configure your server
Open `script.js` and replace:
- `serverIP: "YOUR-SERVER-IP-HERE"` with your Minecraft server address.
- `discordInvite: "https://discord.com/"` with your permanent Discord invite URL.

The server IP copy button works after the real IP is configured. Discord buttons point to your invite after you configure it.

## Publish it
Upload `index.html`, `styles.css`, `script.js`, and the `assets` folder to any static host, such as GitHub Pages, Cloudflare Pages, or Netlify. No backend is needed for this landing page.

## Notes
- Mobile navigation, reveal animations, subtle eclipse motion, and copy-IP interaction are implemented.
- Google Fonts are loaded from Google Fonts; the site falls back to system fonts if unavailable.
- Server status and live Discord member counts are not displayed because those require a real server address/API endpoint and a Discord server ID/widget configuration.
