// Eclipse SMP site configuration.
// Replace these two values with your real server and Discord invite.
const CONFIG = {
  serverIP: "YOUR-SERVER-IP-HERE",
  discordInvite: "https://discord.com/"
};

const ipElement = document.getElementById("server-ip");
const discordLinks = [document.getElementById("discord-link"), document.getElementById("discord-bottom")];
ipElement.textContent = CONFIG.serverIP;
discordLinks.forEach(link => {
  link.href = CONFIG.discordInvite;
  if (CONFIG.discordInvite === "https://discord.com/") {
    link.addEventListener("click", event => {
      event.preventDefault();
      alert("Set CONFIG.discordInvite in script.js to your server's Discord invite link.");
    });
  }
});

document.getElementById("year").textContent = new Date().getFullYear();

const menuToggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav-links");
menuToggle.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
}));

const copyButton = document.getElementById("copy-ip");
const copyFeedback = document.getElementById("copy-feedback");
copyButton.addEventListener("click", async () => {
  if (!CONFIG.serverIP || CONFIG.serverIP === "YOUR-SERVER-IP-HERE") {
    copyFeedback.textContent = "Set your real server IP in script.js first.";
    return;
  }
  try {
    await navigator.clipboard.writeText(CONFIG.serverIP);
    copyFeedback.textContent = "Server address copied. See you in-game.";
  } catch {
    copyFeedback.textContent = "Server address: " + CONFIG.serverIP;
  }
});

const revealObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      revealObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
document.querySelectorAll(".reveal").forEach(element => revealObserver.observe(element));

// Subtle pointer parallax on the eclipse artwork; disabled for touch/reduced motion.
if (window.matchMedia("(hover: hover) and (prefers-reduced-motion: no-preference)").matches) {
  const art = document.querySelector(".hero-art");
  document.querySelector(".hero").addEventListener("pointermove", event => {
    const x = (event.clientX / window.innerWidth - 0.5) * 8;
    const y = (event.clientY / window.innerHeight - 0.5) * 8;
    art.style.marginLeft = `${x}px`;
    art.style.marginTop = `${y}px`;
  });
}
